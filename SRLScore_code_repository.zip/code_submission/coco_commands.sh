# To run this script, follow the installation instructions of the CoCo paper:
# https://github.com/xieyxclack/factual_coco

# You will need to convert the QAGS and SummEval datasets into a line-by-line format, whic is compatible with the
# expected CoCo input format.

python3 run_coco.py --model_path ./bart.large.cnn/ --data_path ./data/qags-cnndm --output_file qags-cnndm-span-scores.txt --mask span
python3 run_coco.py --model_path ./bart.large.cnn/ --data_path ./data/qags-cnndm --output_file qags-cnndm-sent-scores.txt --mask sent

python3 run_coco.py --model_path ./bart.large.xsum/ --data_path ./data/qags-xsum --output_file qags-xsum-span-scores.txt --mask span
python3 run_coco.py --model_path ./bart.large.xsum/ --data_path ./data/qags-xsum --output_file qags-xsum-sent-scores.txt --mask sent

python3 run_coco.py --model_path ./bart.large.cnn/ --data_path ./data/summeval --output_file summeval-span-scores.txt --mask span
python3 run_coco.py --model_path ./bart.large.cnn/ --data_path ./data/summeval --output_file summeval-sent-scores.txt --mask sent