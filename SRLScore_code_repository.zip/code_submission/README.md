# Evaluationg Factual Consistency of Texts with Semantic Role Labeling

Anonymous *SEM 2023 submission

## Installation
To install, we recommend setting up a new environment, particularly for the installing AllenNLP (which frequently causes dependency resolving issues).

### Running Experiments
The central script is `eval_qags.py`, which is computing the proposed method's results.

The scripts `eval.sh` and `eval_leavel_out.sh` systematically evaluate different hyperparameter settings.
The results of these experiments correspond to the reported ablations in the paper.

### Generated Outputs
`qags-cnndm.jsonl`, `qags-xsum.jsonl` and `summeval.jsonl` contain the annotated samples found in the QAGS and SummEval papers, respectively.

`coco_scores` and `eval_results` contain the generated outputs which were used for significance testing.
To reproduce significance scores with permutation tests, run
```bash
python3 significance_testing.py
```
