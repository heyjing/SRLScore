"""
Evaluates qags samples, calculate pearson and spearman correlation between human_annotated_scores and different metric_scores
"""
from typing import List
from statistics import mean, median, variance
import statistics as stat
import argparse
import json
import sys
import os

from tqdm import tqdm
import numpy as np
import time
from nltk.translate.bleu_score import sentence_bleu
from nltk.translate.meteor_score import meteor_score
from sklearn.metrics import mean_squared_error

from utils import *
from calculate_faithful_score import CalculateFactualScore
from bart_score import BARTScorer


def get_samples(arg) -> List[dict]:
    """
    read json file and store each sample in a list
    """
    samples = []
    with open(os.path.join(sys.path[0], arg.json_file)) as f:
        for line in f:
            samples.append(json.loads(line))

    return samples


def compute_rouge_scores(arg) -> List[float]:

    samples: List[dict] = get_samples(arg)

    if arg.json_file == "qags-cnndm.jsonl" or arg.json_file == "qags-xsum.jsonl":
        rouge_scores: List[float] = [
            generate_rouge_scores(
                get_qag_whole_summary_sents(sample), sample["article"]
            )["rouge1"].fmeasure
            for sample in samples
        ]

    if arg.json_file == "summeval.jsonl":
        rouge_scores: List[float] = [
            generate_rouge_scores(sample["decoded"], sample["text"])["rouge1"].fmeasure
            for sample in samples
        ]
    return rouge_scores


def compute_meteor_scores(arg) -> List[float]:
    samples: List[dict] = get_samples(arg)

    if arg.json_file == "qags-cnndm.jsonl" or arg.json_file == "qags-xsum.jsonl":
        meteor_scores: List[float] = [
            meteor_score(
                [sample["article"].split()], get_qag_whole_summary_sents(sample).split()
            )
            for sample in samples
        ]

    if arg.json_file == "summeval.jsonl":
        meteor_scores: List[float] = [
            meteor_score([sample["text"].split()], sample["decoded"].split())
            for sample in samples
        ]

    return meteor_scores


def compute_bleu_scores(arg) -> List[float]:
    samples: List[dict] = get_samples(arg)

    if arg.json_file == "qags-cnndm.jsonl" or arg.json_file == "qags-xsum.jsonl":
        bleu_scores: List[float] = [
            sentence_bleu(
                [sample["article"].split()], get_qag_whole_summary_sents(sample).split()
            )
            for sample in samples
        ]

    if arg.json_file == "summeval.jsonl":
        bleu_scores: List[float] = [
            sentence_bleu([sample["text"].split()], sample["decoded"].split())
            for sample in samples
        ]

    return bleu_scores


def compute_annotated_scores(arg) -> List[float]:
    """
    There are 3 annotations per sample in qags-cnndm and qags-xsum datasets.
    To obtain a single consistency score per summary, the authors first
    take the majority vote for each sentence in a summary, then average the binary scores 
    across summary sentences to produce a final score.
    """

    samples: List[dict] = get_samples(arg)

    if arg.json_file == "qags-cnndm.jsonl" or arg.json_file == "qags-xsum.jsonl":
        sample_scores = []
        for id, sample in tqdm(enumerate(samples)):
            sentence_scores = []

            for sentence_dic in sample["summary_sentences"]:
                # extract the three votes for each summary sentence, like ['yes', 'no', 'yes']
                responses = [el["response"] for el in sentence_dic["responses"]]
                # take the majority vote for each sentence, "yes"
                sentence_scores.append(most_common_list_element(responses))
                # print(responses)

            indic = np.array([1 if x == "yes" else 0 for x in sentence_scores])
            sample_score = np.mean(indic)
            # print(sentence_scores, indic, sample_score)
            # print(f"sample {id} was processed!")
            sample_scores.append(sample_score)

    if arg.json_file == "summeval.jsonl":
        sample_scores = []
        for id, sample in tqdm(enumerate(samples)):
            sample_score = mean(d["consistency"] for d in sample["expert_annotations"])
            sample_scores.append(sample_score)

    return sample_scores


def compute_bartscore(arg) -> List[float]:

    samples: List[dict] = get_samples(arg)
    src_lines, sys_lines = get_src_sys_lines_for_BART(samples, arg.json_file)

    # load bart models: BARTScore or BARTScore-CNN
    if arg.metric_name == "bartscore":
        bart_scorer = BARTScorer(device="cuda:0", checkpoint="facebook/bart-large")
    if arg.metric_name == "bartscore_cnn":
        bart_scorer = BARTScorer(device="cuda:0", checkpoint="facebook/bart-large-cnn")
    if arg.metric_name == "bartscore_para":
        bart_scorer = BARTScorer(device="cuda:0", checkpoint="facebook/bart-large-cnn")
        bart_scorer.load()

    return bart_scorer.score(src_lines, sys_lines, batch_size=4)


def compute_goodrich_inspired_score(arg) -> List[float]:
    samples: List[dict] = get_samples(arg)

    weights = [1 / 3, 0, 1 / 3, 1 / 3, 0, 0, 0]

    calcu = CalculateFactualScore(
        do_coref=False, string_comparison_method="goodrich", weights=weights
    )

    if arg.json_file == "qags-cnndm.jsonl" or arg.json_file == "qags-xsum.jsonl":
        srl_scores: List[float] = [
            calcu.goodrich_inspired_score(
                sample["article"], get_qag_whole_summary_sents(sample)
            )
            for sample in tqdm(samples, desc="processing sample: ")
        ]

    if arg.json_file == "summeval.jsonl":
        srl_scores: List[float] = [
            calcu.goodrich_inspired_score(sample["text"], sample["decoded"])
            for sample in tqdm(samples, desc="processing sample: ")
        ]

    return srl_scores


def compute_srl_metric_scores(arg) -> List[float]:

    samples: List[dict] = get_samples(arg)

    input_do_coref: str = arg.do_coref
    do_coref = True if input_do_coref == "True" else False

    method: str = arg.string_comparison_method

    if arg.weights == "1/3":
        weights = [1 / 3, 0, 1 / 3, 1 / 3, 0, 0, 0]
    elif arg.weights == "leave_agent":
        weights = [0, 1 / 6, 1 / 6, 1 / 6, 1 / 6, 1 / 6, 1 / 6]
    elif arg.weights == "leave_negation":
        weights = [1 / 6, 0, 1 / 6, 1 / 6, 1 / 6, 1 / 6, 1 / 6]
    elif arg.weights == "leave_relation":
        weights = [1 / 6, 1 / 6, 0, 1 / 6, 1 / 6, 1 / 6, 1 / 6]
    elif arg.weights == "leave_patient":
        weights = [1 / 6, 1 / 6, 1 / 6, 0, 1 / 6, 1 / 6, 1 / 6]
    elif arg.weights == "leave_recipient":
        weights = [1 / 6, 1 / 6, 1 / 6, 1 / 6, 0, 1 / 6, 1 / 6]
    elif arg.weights == "leave_time":
        weights = [1 / 6, 1 / 6, 1 / 6, 1 / 6, 1 / 6, 0, 1 / 6]
    elif arg.weights == "leave_location":
        weights = [1 / 6, 1 / 6, 1 / 6, 1 / 6, 1 / 6, 1 / 6, 0]
    else:
        weights = [1 / 7, 1 / 7, 1 / 7, 1 / 7, 1 / 7, 1 / 7, 1 / 7]

    calcu = CalculateFactualScore(
        do_coref=do_coref, string_comparison_method=method, weights=weights
    )

    if arg.json_file == "qags-cnndm.jsonl" or arg.json_file == "qags-xsum.jsonl":
        srl_scores: List[float] = [
            calcu.calculate_factual_score(
                sample["article"], get_qag_whole_summary_sents(sample)
            )
            for sample in tqdm(samples, desc="processing sample: ")
        ]

    if arg.json_file == "summeval.jsonl":
        srl_scores: List[float] = [
            calcu.calculate_factual_score(sample["text"], sample["decoded"])
            for sample in tqdm(samples, desc="processing sample: ")
        ]

    return srl_scores


def compute_metric_scores(arg) -> List[float]:
    metrics = {
        "rouge": compute_rouge_scores,
        "meteor": compute_meteor_scores,
        "bleu": compute_bleu_scores,
        "srl": compute_srl_metric_scores,
        "goodrich": compute_goodrich_inspired_score,
        "bartscore": compute_bartscore,
        "bartscore_cnn": compute_bartscore,
        "bartscore_para": compute_bartscore,
    }
    return metrics.get(arg.metric_name)(arg)


def eval(arg):

    human_annotated_scores: List[float] = compute_annotated_scores(arg)

    start = time.time()
    metric_scores: List[float] = compute_metric_scores(arg)
    end = time.time()

    print(
        f"human_annotated_scores: {human_annotated_scores}, length is {len(human_annotated_scores)}\n",
        f"metric_scores: {metric_scores}, length is {len(metric_scores)}\n",
    )

    (
        pearson_corr,
        pearson_p_value,
        spearman_corr,
        spearman_p_value,
    ) = calculate_correlation_score(human_annotated_scores, metric_scores)

    results = {
        "setting": f"{arg.json_file} + {arg.metric_name} + weights {arg.weights} + Do coref: {arg.do_coref} + {arg.string_comparison_method} similarity",
        "processing_time": f"Processing {arg.json_file} file took {(end - start):.6f} s.",
        "human_annotated_scores": human_annotated_scores,
        "metric_scores": metric_scores,
        "mean_metric_scores": mean(metric_scores),
        "min_metric_scores": min(metric_scores),
        "max_metric_scores": max(metric_scores),
        "median_metric_scores": median(metric_scores),
        "std": stat.stdev(metric_scores),
        "variance": variance(metric_scores),
        "mean_squared_error": mean_squared_error(human_annotated_scores, metric_scores),
        "pearson_correlation": pearson_corr,
        "pearson_p_value": pearson_p_value,
        "spearman_corr": spearman_corr,
        "spearman_p_value": spearman_p_value,
        "correlation_description": f"pearson correlation is {pearson_corr} with pearson_p_value {pearson_p_value}; spearman correlation is {spearman_corr} with spearman_p_value {spearman_p_value}",
    }

    return results


if __name__ == "__main__":

    PARSER = argparse.ArgumentParser()

    PARSER.add_argument(
        "--json_file",
        type=str,
        help="Json file name: 'qags-cnndm.jsonl' or 'qags-xsum.jsonl' or 'summeval.jsonl'",
    )

    PARSER.add_argument(
        "--metric_name",
        type=str,
        help="Metric name: 'rouge', 'bleu', 'meteor', 'srl', 'goodrich', 'bartscore', 'bartscore_cnn', 'bartscore_para'",
    )

    PARSER.add_argument(
        "--weights",
        type=str,
        help="default is 1/7 weights; enter '1/3' to change to openIE equivalent",
    )

    PARSER.add_argument(
        "--string_comparison_method",
        type=str,
        help="string_comparison_method: 'exact' or 'rouge' or 'spacy'",
    )

    PARSER.add_argument("--do_coref", type=str, help="Please enter 'True' or 'False'")

    PARSER.add_argument("--output", type=str, help="Path for saving data")

    ARGS = PARSER.parse_args()

    if ARGS.json_file not in [
        "qags-cnndm.jsonl",
        "qags-xsum.jsonl",
        "summeval.jsonl",
    ]:
        raise RuntimeError(
            "To run script, please specify 'qags-cnndm.jsonl' or 'qags-xsum.jsonl' or 'summeval.jsonl'"
        )

    if ARGS.metric_name not in [
        "rouge",
        "srl",
        "goodrich",
        "bartscore",
        "bartscore_cnn",
        "bartscore_para",
        "meteor",
        "bleu",
    ]:
        raise RuntimeError(
            "To run script, please specify 'srl' or 'rouge' or 'goodrich' or 'bartscore' or 'bartscore_cnn'"
        )

    if ARGS.metric_name == "srl" and ARGS.do_coref not in ["True", "False"]:
        raise RuntimeError(
            "To use SRL metric please specify do_coref as 'True' or 'False' first"
        )

    if ARGS.metric_name == "srl" and ARGS.string_comparison_method not in [
        "exact",
        "spacy",
        "rouge",
    ]:
        raise RuntimeError(
            "To run script please specify comparison methods 'exact', 'spacy' or 'rouge'"
        )

    results = eval(ARGS)
    save_data(results, ARGS)
